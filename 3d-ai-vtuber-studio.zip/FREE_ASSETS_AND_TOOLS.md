# 🌐 Free Asset Libraries & KeenTools VTuber Directory

* KeenTools FaceBuilder & Tracker: https://keentools.io/
* VRoid Studio: https://vroid.com/
* Tripo3D API: https://www.tripo3d.ai/