# Blender Headless Mesh Rigging Engine with KeenTools
import bpy, sys
print("Blender Mesh Processing Engine")