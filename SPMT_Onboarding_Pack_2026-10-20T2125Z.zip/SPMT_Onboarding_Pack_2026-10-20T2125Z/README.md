# SPMT Ecosystem — Newcomer Onboarding Pack

**Pack timestamp:** 2026-10-20 21:25 UTC  
**Current phase:** Phase -1 — Access, repository hygiene, and recovery of stranded work; current clean-pass status is read-only inventory and production-readiness triage.  
**Purpose:** Bring a new developer or AI assistant up to speed without relying on undocumented assumptions or treating old findings as current truth.

## Start here

1. Read this README completely.
2. Read `PLAN_2026-10-20T2125Z.txt` for the current master plan, task IDs, phase gates, and handoff instructions.
3. Read `History/2026-10-20_clean-pass-01.md` for the evidence snapshot and findings verified during the 2026-10-20 clean pass.
4. Use `History/spmt_master_road_to_production_snapshot_2026-10-20.txt` as the preserved master-plan snapshot from that pass. The timestamped plan at the pack root is the newer onboarding copy for this pack.
5. Before changing anything, refresh repository state, PR metadata, checks, deployment ownership, and live health against current evidence.

## What SPMT is

SPMT is a multi-repository, multi-service ecosystem—not one app and not one deploy target. Relevant repositories and services seen in the working plan include:

- `Mtman1987/ApolloStation` — a broader app/UI and production-readiness effort; do not assume it is already the production authority for every service.
- `Mtman1987/fly-machine-rotator` — the intended operational control-plane repository; its documented MCP boundary is narrow and authenticated, not a general-purpose shell or unrestricted deploy interface.
- `Mtman1987/hearmeout-main` — HearMeOut rooms, voice/audio paths, and related worker integrations.
- `Mtman1987/streamweaver` — shared stream/voice/TTS behavior and fallback paths.
- `Mtman1987/DiscordStreamHub` — Discord streaming/spotlight integrations.
- `Mtman1987/chat-tag`, `Mtman1987/spmt-live`, and `Mtman1987/spacemountain-live` — related app/admin/live surfaces.

These names are an orientation list, not proof of current deployment ownership. Verify the exact production app, workflow, environment, branch, and release authority before acting.

## Current phase and known blockers (as of this pack timestamp)

- **Current phase:** access/repository inventory and recovery of stranded work. The 2026-10-20 clean pass was read-only.
- **GitHub PR queue:** 55 open PRs were returned across eight repositories at the recorded search time. This is a review queue, not evidence that every PR is stale or should be closed.
- **HearMeOut audio:** PR #218 and #186 describe conflicting room-audio fallback policies; both were reported non-mergeable. Do not merge both as-is. Establish the product contract and resolve the merge state.
- **DiscordStreamHub Spotlight:** PR #111 validation failed TypeScript checking at `src/app/api/community-spotlight/route.ts(36,16)` because `user` implicitly has type `any`. Use the actual type contract, then rerun the complete checks.
- **StreamWeaver fallback chains:** PR #399 had no associated runs returned by the inspected query. Its status is **unknown**, not pass or fail.
- **Discord audio relay:** local commit `4ff25896554273646b5555ed63d5f29608ec003a` was present on local branch `fix/discord-say-player-relay`, but no matching GitHub remote branch was found. It is not verified as published, merged, or deployed.
- **Fly/Rotator access:** `flyctl` in the recovery Sprite was not authenticated. This does not prove the live Rotator has no credentials. The documented live Rotator MCP endpoint was not authenticated or invoked in this pass.
- **ApolloStation release gates:** script presence is not a passing audit. Re-run release/cutover audits and workflows at an exact recorded SHA; preserve existing production authority until formal cutover and rollback gates pass.

See the dated history report for details and evidence boundaries.

## Non-negotiable rules for any AI or developer

1. **Preserve product behavior.** Hardening means fix, simplify, document, test, and secure existing behavior—not silently add or remove features.
2. **Do not infer success.** Local tests, CI, mergeability, a deployment workflow, and live runtime health are different kinds of evidence. Record each separately.
3. **Unknown is not failure or success.** Missing checks, inaccessible logs, stale docs, or unavailable auth must be labeled unknown/blocked.
4. **No mass cleanup.** Do not mass-close PRs, delete branches, or remove files without inspecting their unique work and documenting a reason and destination.
5. **No production mutation by assumption.** No merge, deploy, machine rotation, secret rotation, or live config change unless explicitly authorized and the intended safe procedure is verified.
6. **Use the intended control plane.** Prefer the configured Rotator control surface. Do not invent endpoints or fall back silently to an unrelated repo, Sprite, or shell.
7. **Protect secrets.** Never put tokens, cookies, secret values, private machine IPs, user data, or credential-bearing URLs into issues, logs, plans, or this archive.
8. **Security gate:** comprehensive authentication/security review is the final production-readiness gate. Urgent exposures must still be contained immediately.
9. **Record UTC timestamps and exact identifiers.** Include repository, branch, commit SHA, PR number, workflow run URL/status, app/environment, and evidence window when applicable.
10. **Keep the plan canonical.** Maintain one canonical working plan; store dated snapshots and clean-pass reports under `History/`. Do not silently overwrite historical evidence.

## Recommended work protocol

For each task:

1. State the user-visible behavior and expected contract.
2. Inspect current source and current production/deployment ownership.
3. Record the exact base/head SHA and relevant PR/workflow identifiers.
4. Make the smallest compatible change that preserves features.
5. Run focused regression tests, full required checks, and diff/syntax validation as appropriate.
6. Review permissions, secrets exposure, failure modes, idempotency, observability, and rollback.
7. Merge only through the approved process after checks/review.
8. Deploy only through the verified intended workflow and authorized release gate.
9. Verify runtime behavior and logs after deployment; record what was actually observed.
10. Add a dated history entry with outcome, evidence, remaining blockers, and next safe action.

## How to resume work in a new session

Paste this instruction along with the pack:

> Read the onboarding README and timestamped plan first. Continue from the current phase. Refresh evidence before acting. Do not repeat already verified work unless its source state changed. Clearly distinguish verified, blocked, and unknown. Preserve all product behavior; no mass PR/branch cleanup. Do not merge, deploy, alter live settings, or touch secrets without explicit authorization and verified safe procedure. Update the handoff and add a new dated History entry when work is completed.

## Contents

- `README.md` — newcomer orientation, rules, and resume protocol.
- `PLAN_2026-10-20T2125Z.txt` — timestamped current plan copy, updated with current phase/status.
- `History/2026-10-20_clean-pass-01.md` — evidence report from the clean pass.
- `History/spmt_master_road_to_production_snapshot_2026-10-20.txt` — preserved plan snapshot from the same date.

This pack contains operational documentation and findings. It intentionally does **not** contain credentials, secret values, raw private logs, or deployment artifacts.
